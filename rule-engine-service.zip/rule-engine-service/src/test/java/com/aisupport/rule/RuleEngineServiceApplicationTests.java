package com.aisupport.rule;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RuleEngineServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
