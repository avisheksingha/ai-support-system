package com.aisupport.routing;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RoutingServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
